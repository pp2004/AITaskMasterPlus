# AI-Powered Event & Product Management Platform

## Overview

This is a Streamlit-based web application that combines event planning functionality with AI-powered product management capabilities. The application is built using Python 3.11 and integrates with Azure OpenAI services for AI features. It uses SQLite for data persistence and is designed to run on Replit's platform.

## System Architecture

### Frontend Architecture
- **Framework**: Streamlit for web interface
- **Structure**: Multi-tab application with sidebar navigation
- **Styling**: Custom theme configuration with light base theme
- **Components**: Modular design with separate files for different features

### Backend Architecture
- **Runtime**: Python 3.11
- **Database**: SQLite for local data storage
- **AI Integration**: Azure OpenAI API for product management features
- **Data Models**: Pydantic models for type validation and serialization

### Application Structure
```
├── app.py                    # Main application entry point
├── event_planner.py          # Week 2/3 event planning functionality
├── ai_product_manager.py     # Week 4 AI product management features
├── ai_service.py            # Azure OpenAI integration service
├── database.py              # SQLite database management
├── models.py                # Pydantic data models
└── .streamlit/config.toml   # Streamlit configuration
```

## Key Components

### 1. Event Management System
- **Purpose**: Provides CRUD operations for event planning
- **Features**: 
  - Event list view with filtering capabilities
  - Create new events with form validation
  - Status tracking (open, fully booked, completed)
  - Host management system
- **Data Model**: Events with date validation, status codes, and participant tracking

### 2. AI Product Manager
- **Purpose**: Simulates product management workflows using AI
- **Challenges**:
  - Product ideation and roadmap development
  - Azure OpenAI integration testing
  - Prompt engineering exercises
  - RAG (Retrieval Augmented Generation) and security features
- **AI Integration**: Uses Azure OpenAI for generating product concepts and responses

### 3. Database Layer
- **Technology**: SQLite
- **Tables**: 
  - `events`: Stores event data with validation
  - `hosts`: Manages event host information
- **Features**: Automatic schema initialization and sample data seeding

### 4. AI Service Layer
- **Provider**: Azure OpenAI
- **Capabilities**:
  - Chat completions using GPT-4
  - Token counting for cost management
  - Configurable model parameters
  - Error handling and fallback mechanisms

## Data Flow

1. **User Interaction**: Users navigate through sidebar to select Week 2/3 (Event Planner) or Week 4 (AI Product Manager)
2. **Event Management**: 
   - Users can view, create, update, and delete events
   - Data is validated using Pydantic models
   - SQLite database persists all changes
3. **AI Features**:
   - User inputs are processed through Azure OpenAI
   - Responses are generated based on configured prompts
   - Token usage is tracked for optimization

## External Dependencies

### Required Services
- **Azure OpenAI**: For AI-powered product management features
  - API Key authentication
  - Configurable endpoints and model versions
  - Support for GPT-4 and embedding models

### Python Packages
- `streamlit`: Web application framework
- `openai`: Azure OpenAI client library
- `pandas`: Data manipulation and analysis
- `pydantic`: Data validation and serialization
- `python-dotenv`: Environment variable management
- `tiktoken`: Token counting for AI requests

### Environment Variables
```
AZURE_OPENAI_KEY=your_azure_openai_key_here
AZURE_OPENAI_ENDPOINT=https://your-resource-name.openai.azure.com/
AZURE_OPENAI_VERSION=2024-02-15-preview
AZURE_OPENAI_MODEL=gpt-4
AZURE_OPENAI_EMBEDDING_MODEL=text-embedding-ada-002
DATABASE_PATH=events.db
```

## Deployment Strategy

### Platform
- **Target**: Replit autoscale deployment
- **Runtime**: Nix with Python 3.11 module
- **Port**: 5000 (configured for Streamlit server)

### Configuration
- Uses Replit's workflow system for automated deployment
- Streamlit server configured for headless operation
- Environment variables managed through Replit secrets

### Scaling Considerations
- SQLite suitable for development and small-scale production
- Azure OpenAI provides scalable AI capabilities
- Streamlit handles concurrent users efficiently

## User Preferences

Preferred communication style: Simple, everyday language.

## Changelog

Changelog:
- June 18, 2025. Initial setup