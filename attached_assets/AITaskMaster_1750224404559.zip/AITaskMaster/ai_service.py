import os
import streamlit as st
from openai import AzureOpenAI
from typing import List, Dict, Any, Optional
import tiktoken
import json

class AIService:
    def __init__(self):
        self.client = self._initialize_client()
        self.encoding = tiktoken.get_encoding("cl100k_base")
    
    def _initialize_client(self) -> Optional[AzureOpenAI]:
        """Initialize Azure OpenAI client"""
        try:
            api_key = os.getenv('AZURE_OPENAI_KEY')
            api_version = os.getenv('AZURE_OPENAI_VERSION', '2024-02-15-preview')
            azure_endpoint = os.getenv('AZURE_OPENAI_ENDPOINT')
            
            if not all([api_key, azure_endpoint]):
                st.error("Azure OpenAI credentials not found. Please check your environment variables.")
                return None
            
            return AzureOpenAI(
                api_key=api_key,
                api_version=api_version,
                azure_endpoint=azure_endpoint
            )
        except Exception as e:
            st.error(f"Failed to initialize Azure OpenAI client: {str(e)}")
            return None
    
    def count_tokens(self, text: str) -> int:
        """Count tokens in a text string"""
        return len(self.encoding.encode(text))
    
    def generate_response(
        self,
        messages: List[Dict[str, str]],
        temperature: float = 0.7,
        max_completion_tokens: int = 1000,
        model: str = None
    ) -> Optional[str]:
        """Generate response using Azure OpenAI"""
        if not self.client:
            return None
        
        try:
            # Use environment model if not specified
            if model is None:
                model = os.getenv('AZURE_OPENAI_MODEL', 'gpt-4')
            
            # Prepare parameters based on model type
            params = {
                "model": model,
                "messages": messages
            }
            
            # o3 models don't support temperature parameter
            if "o3" not in model.lower():
                params["temperature"] = temperature
            
            # Use max_completion_tokens for o3 models, max_tokens for others
            if "o3" in model.lower():
                params["max_completion_tokens"] = max_completion_tokens
            else:
                params["max_tokens"] = max_completion_tokens
                
            response = self.client.chat.completions.create(**params)
            return response.choices[0].message.content
        except Exception as e:
            st.error(f"Error generating AI response: {str(e)}")
            return None
    
    def generate_product_idea(self) -> Optional[str]:
        """Generate a product idea using AI"""
        messages = [
            {
                "role": "system",
                "content": "You are a product manager expert. Generate innovative product ideas with clear target audience, USP, and core features."
            },
            {
                "role": "user",
                "content": """Generate a product idea similar to "AI-Powered Fraud Detection for E-Commerce". 
                
                Format your response as:
                
                **Product Concept:** [1-paragraph summary]
                
                **Target Audience:** [specific audience]
                
                **Unique Selling Proposition (USP):** [clear USP]
                
                **Core Features:**
                • [Feature 1]
                • [Feature 2] 
                • [Feature 3]"""
            }
        ]
        
        return self.generate_response(messages, temperature=0.7, max_completion_tokens=800)
    
    def prioritize_features(self, product_concept: str) -> Optional[str]:
        """Generate and prioritize additional features using MoSCoW method"""
        messages = [
            {
                "role": "system",
                "content": "You are a product manager expert. Use Chain of Thought reasoning to brainstorm and prioritize features using the MoSCoW method."
            },
            {
                "role": "user",
                "content": f"""For this product concept: {product_concept}
                
                Step 1: Brainstorm 5 additional features (think step by step about user needs)
                Step 2: Prioritize them using MoSCoW method (Must-have/Should-have/Could-have/Won't-have)
                
                Format as a table:
                | Feature | Priority | Reasoning |
                |---------|----------|-----------|
                | [Feature] | [Must/Should/Could/Won't] | [Brief reasoning] |"""
            }
        ]
        
        return self.generate_response(messages, temperature=0.6, max_completion_tokens=1000)
    
    def create_roadmap(self, product_concept: str, features: str) -> Optional[str]:
        """Create a 4-quarter roadmap"""
        messages = [
            {
                "role": "system",
                "content": "You are a product manager creating realistic development roadmaps."
            },
            {
                "role": "user",
                "content": f"""Based on this product concept: {product_concept}
                
                And these prioritized features: {features}
                
                Create a 4-quarter roadmap with milestones:
                
                | Q1 2024 | Q2 2024 | Q3 2024 | Q4 2024 |
                |---------|---------|---------|---------|
                | [Feature/Milestone] | [Feature/Milestone] | [Feature/Milestone] | [Feature/Milestone] |
                
                Include reasoning for the timeline."""
            }
        ]
        
        return self.generate_response(messages, temperature=0.5, max_completion_tokens=400)
    
    def create_user_story(self, feature_description: str) -> Optional[str]:
        """Create a GitLab-style user story"""
        messages = [
            {
                "role": "system",
                "content": "You are an expert in writing user stories following GitLab format."
            },
            {
                "role": "user",
                "content": f"""Write a GitLab-style user story for this feature: {feature_description}
                
                Format:
                **User Story:**
                As a [user], I want [action] so that [benefit].
                
                **Acceptance Criteria:**
                • [Criterion 1]
                • [Criterion 2]
                • [Criterion 3]"""
            }
        ]
        
        return self.generate_response(messages, temperature=0.4, max_completion_tokens=500)
    
    def cybersecurity_analysis(self, topic: str) -> Optional[str]:
        """Generate cybersecurity analysis"""
        messages = [
            {
                "role": "system",
                "content": "You are a cybersecurity expert with deep knowledge of security protocols, threats, and mitigation strategies."
            },
            {
                "role": "user",
                "content": f"Explain how {topic} works from a cybersecurity perspective. Include potential risks and security considerations."
            }
        ]
        
        return self.generate_response(messages, temperature=0.3, max_completion_tokens=500)
    
    def compare_prompting_techniques(self, question: str) -> Dict[str, str]:
        """Compare zero-shot vs few-shot prompting"""
        # Zero-shot
        zero_shot_messages = [
            {"role": "user", "content": question}
        ]
        
        # Few-shot with examples
        few_shot_messages = [
            {
                "role": "user",
                "content": "Explain machine learning"
            },
            {
                "role": "assistant",
                "content": "Machine learning is a method where computers learn patterns from data to make predictions without being explicitly programmed for each task."
            },
            {
                "role": "user",
                "content": "Explain artificial intelligence"
            },
            {
                "role": "assistant",
                "content": "Artificial intelligence is the simulation of human intelligence by machines, enabling them to perform tasks that typically require human cognition like reasoning and learning."
            },
            {
                "role": "user",
                "content": question
            }
        ]
        
        zero_shot_response = self.generate_response(zero_shot_messages, temperature=0.7, max_completion_tokens=400)
        few_shot_response = self.generate_response(few_shot_messages, temperature=0.7, max_completion_tokens=400)
        
        return {
            "zero_shot": zero_shot_response or "Error generating response",
            "few_shot": few_shot_response or "Error generating response"
        }
    
    def chain_of_thought_reasoning(self, problem: str) -> Optional[str]:
        """Demonstrate chain-of-thought reasoning"""
        messages = [
            {
                "role": "system",
                "content": "You must think step by step and show your reasoning process clearly."
            },
            {
                "role": "user",
                "content": f"{problem}\n\nLet's think step by step:"
            }
        ]
        
        return self.generate_response(messages, temperature=0.3, max_completion_tokens=400)
