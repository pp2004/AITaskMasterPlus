import streamlit as st
import pandas as pd
from database import DatabaseManager
from models import Event, CreateEventRequest, Host
import time
from typing import List
from datetime import datetime

def render_event_planner():
    """Render the event planner tab"""
    st.header("📅 Event Planner - Week 2/3")
    
    # Initialize database
    db = DatabaseManager()
    
    # Create tabs for different views
    tab1, tab2 = st.tabs(["📋 Event List", "➕ Create Event"])
    
    with tab1:
        render_event_list(db)
    
    with tab2:
        render_create_event(db)

def render_event_list(db: DatabaseManager):
    """Render the event list view"""
    st.subheader("Event Overview")
    
    # Add filters
    col1, col2, col3 = st.columns(3)
    
    with col1:
        status_filter = st.selectbox(
            "Filter by Status",
            ["All", "Open (0)", "Fully Booked (1)", "Completed (2)"],
            key="status_filter"
        )
    
    with col2:
        host_filter = st.text_input("Filter by Host", key="host_filter")
    
    with col3:
        if st.button("🔄 Refresh", key="refresh_events"):
            st.rerun()
    
    # Loading animation
    with st.spinner("Loading events..."):
        time.sleep(0.5)  # Simulate loading
        events = db.get_all_events()
    
    if not events:
        st.info("📭 No events found. Create your first event using the 'Create Event' tab!")
        return
    
    # Apply filters
    filtered_events = events
    
    if status_filter != "All":
        status_value = int(status_filter.split("(")[1].split(")")[0])
        filtered_events = [e for e in filtered_events if e.status == status_value]
    
    if host_filter:
        filtered_events = [e for e in filtered_events if host_filter.lower() in e.eventHost.lower()]
    
    # Display events in a table
    if filtered_events:
        df_data = []
        for event in filtered_events:
            status_text = {0: "🟢 Open", 1: "🟡 Fully Booked", 2: "🔴 Completed"}[event.status]
            df_data.append({
                "ID": event.id,
                "Date": event.eventDate,
                "Status": status_text,
                "RSVP By": event.rsvpBy,
                "Title": event.eventTitle,
                "Host": event.eventHost,
                "Location": event.eventLocation,
                "Pax": event.pax
            })
        
        df = pd.DataFrame(df_data)
        
        # Display table with selection
        event_selection = st.dataframe(
            df,
            use_container_width=True,
            hide_index=True
        )
        
        # Event management buttons
        st.subheader("Event Management")
        col1, col2, col3 = st.columns(3)
        
        with col1:
            event_ids = [e.id for e in filtered_events if e.id is not None]
            selected_id = int(st.number_input(
                "Select Event ID for action:",
                min_value=1,
                max_value=max(event_ids) if event_ids else 1,
                key="selected_event_id"
            ))
        
        with col2:
            if st.button("✏️ Edit Event", key="edit_event"):
                st.session_state.edit_event_id = selected_id
                st.session_state.show_edit_form = True
        
        with col3:
            if st.button("🗑️ Delete Event", key="delete_event", type="secondary"):
                if st.session_state.get('confirm_delete') != selected_id:
                    st.session_state.confirm_delete = selected_id
                    st.warning(f"⚠️ Click 'Delete Event' again to confirm deletion of Event ID {selected_id}")
                else:
                    with st.spinner("Deleting event..."):
                        time.sleep(0.5)
                        if db.delete_event(selected_id):
                            st.success(f"✅ Event {selected_id} deleted successfully!")
                            del st.session_state.confirm_delete
                            time.sleep(1)
                            st.rerun()
                        else:
                            st.error(f"❌ Failed to delete event {selected_id}")
        
        # Edit form
        if st.session_state.get('show_edit_form') and st.session_state.get('edit_event_id'):
            render_edit_event_form(db, st.session_state.edit_event_id)
    
    else:
        st.info("🔍 No events match your current filters.")

def render_edit_event_form(db: DatabaseManager, event_id: int):
    """Render the edit event form"""
    st.subheader(f"✏️ Edit Event {event_id}")
    
    # Get current event data
    event = db.get_event_by_id(event_id)
    if not event:
        st.error("Event not found!")
        return
    
    # Get hosts for dropdown
    hosts = db.get_all_hosts()
    host_names = [host.name for host in hosts]
    
    with st.form(f"edit_event_form_{event_id}"):
        col1, col2 = st.columns(2)
        
        with col1:
            # Parse existing date for date picker
            try:
                event_date_obj = datetime.strptime(event.eventDate, "%m/%d/%y").date()
            except:
                event_date_obj = None
            
            # Date picker for event date
            event_date_picker = st.date_input(
                "Event Date*",
                value=event_date_obj,
                help="Select the event date"
            )
            event_date = event_date_picker.strftime("%m/%d/%y") if event_date_picker else ""
            
            # Manual date input option
            manual_event_date = st.text_input(
                "Or enter manually (MM/DD/YY)*",
                value=event.eventDate,
                help="Format: MM/DD/YY (e.g., 07/15/24)",
                key=f"manual_event_date_{event_id}"
            )
            if manual_event_date.strip():
                event_date = manual_event_date
            
            # Parse existing RSVP date
            try:
                rsvp_date_obj = datetime.strptime(event.rsvpBy, "%m/%d/%y").date()
            except:
                rsvp_date_obj = None
            
            # Date picker for RSVP deadline
            rsvp_date_picker = st.date_input(
                "RSVP Deadline*",
                value=rsvp_date_obj,
                help="Select the RSVP deadline"
            )
            rsvp_by = rsvp_date_picker.strftime("%m/%d/%y") if rsvp_date_picker else ""
            
            # Manual RSVP date input option
            manual_rsvp_date = st.text_input(
                "Or enter manually (MM/DD/YY)*",
                value=event.rsvpBy,
                help="Format: MM/DD/YY (e.g., 07/10/24)",
                key=f"manual_rsvp_date_{event_id}"
            )
            if manual_rsvp_date.strip():
                rsvp_by = manual_rsvp_date
            
            event_title = st.text_input(
                "Event Title*",
                value=event.eventTitle,
                max_chars=200
            )
            
            pax = st.text_input(
                "Number of Participants*",
                value=event.pax,
                help="Enter a positive number"
            )
        
        with col2:
            status = st.selectbox(
                "Event Status*",
                options=[0, 1, 2],
                format_func=lambda x: {0: "Open", 1: "Fully Booked", 2: "Completed"}[x],
                index=event.status
            )
            
            # Host selection
            current_host_index = 0
            if event.eventHost in host_names:
                current_host_index = host_names.index(event.eventHost)
            
            event_host = st.selectbox(
                "Event Host*",
                options=host_names + ["Other"],
                index=current_host_index
            )
            
            if event_host == "Other":
                event_host = st.text_input("Custom Host Name*", value=event.eventHost)
            
            event_location = st.text_input(
                "Event Location*",
                value=event.eventLocation,
                max_chars=200
            )
        
        col1, col2, col3 = st.columns(3)
        
        with col1:
            submit_edit = st.form_submit_button("💾 Update Event", type="primary")
        
        with col2:
            cancel_edit = st.form_submit_button("❌ Cancel")
        
        if cancel_edit:
            st.session_state.show_edit_form = False
            if 'edit_event_id' in st.session_state:
                del st.session_state.edit_event_id
            st.rerun()
        
        if submit_edit:
            # Validate form
            errors = validate_event_form(event_date, rsvp_by, event_title, event_host, event_location, pax)
            
            if errors:
                for error in errors:
                    st.error(error)
            else:
                # Update event
                event_data = {
                    'eventDate': event_date,
                    'status': status,
                    'rsvpBy': rsvp_by,
                    'eventTitle': event_title,
                    'eventHost': event_host,
                    'eventLocation': event_location,
                    'pax': pax
                }
                
                with st.spinner("Updating event..."):
                    time.sleep(0.5)
                    if db.update_event(event_id, event_data):
                        st.success("✅ Event updated successfully!")
                        st.session_state.show_edit_form = False
                        if 'edit_event_id' in st.session_state:
                            del st.session_state.edit_event_id
                        time.sleep(1)
                        st.rerun()
                    else:
                        st.error("❌ Failed to update event")

def render_create_event(db: DatabaseManager):
    """Render the create event form"""
    st.subheader("➕ Create New Event")
    
    # Get hosts for dropdown
    hosts = db.get_all_hosts()
    host_names = [host.name for host in hosts]
    
    with st.form("create_event_form", clear_on_submit=True):
        st.write("Fill in the event details below:")
        
        col1, col2 = st.columns(2)
        
        with col1:
            # Date picker for event date
            event_date_picker = st.date_input(
                "Event Date*",
                help="Select the event date"
            )
            event_date = event_date_picker.strftime("%m/%d/%y") if event_date_picker else ""
            
            # Manual date input option
            manual_event_date = st.text_input(
                "Or enter manually (MM/DD/YY)*",
                placeholder="07/15/24",
                help="Format: MM/DD/YY (e.g., 07/15/24)",
                key="manual_event_date"
            )
            if manual_event_date.strip():
                event_date = manual_event_date
            
            # Date picker for RSVP deadline
            rsvp_date_picker = st.date_input(
                "RSVP Deadline*",
                help="Select the RSVP deadline"
            )
            rsvp_by = rsvp_date_picker.strftime("%m/%d/%y") if rsvp_date_picker else ""
            
            # Manual RSVP date input option
            manual_rsvp_date = st.text_input(
                "Or enter manually (MM/DD/YY)*",
                placeholder="07/10/24",
                help="Format: MM/DD/YY (e.g., 07/10/24)",
                key="manual_rsvp_date"
            )
            if manual_rsvp_date.strip():
                rsvp_by = manual_rsvp_date
            
            event_title = st.text_input(
                "Event Title*",
                placeholder="Team Building Lunch",
                max_chars=200
            )
            
            pax = st.text_input(
                "Number of Participants*",
                placeholder="10",
                help="Enter a positive number"
            )
        
        with col2:
            status = st.selectbox(
                "Event Status*",
                options=[0, 1, 2],
                format_func=lambda x: {0: "Open", 1: "Fully Booked", 2: "Completed"}[x],
                index=0
            )
            
            event_host = st.selectbox(
                "Event Host*",
                options=host_names + ["Other"]
            )
            
            if event_host == "Other":
                event_host = st.text_input("Custom Host Name*", placeholder="John Doe")
            
            event_location = st.text_input(
                "Event Location*",
                placeholder="Conference Room A, Level 5",
                max_chars=200
            )
        
        submitted = st.form_submit_button("🎉 Create Event", type="primary")
        
        if submitted:
            # Validate form
            errors = validate_event_form(event_date, rsvp_by, event_title, event_host, event_location, pax)
            
            if errors:
                for error in errors:
                    st.error(error)
            else:
                # Create event
                event_data = {
                    'eventDate': event_date,
                    'status': status,
                    'rsvpBy': rsvp_by,
                    'eventTitle': event_title,
                    'eventHost': event_host,
                    'eventLocation': event_location,
                    'pax': pax
                }
                
                with st.spinner("Creating event..."):
                    time.sleep(1)  # Simulate processing
                    try:
                        event_id = db.create_event(event_data)
                        st.success(f"✅ Event created successfully! Event ID: {event_id}")
                        st.balloons()  # Animation
                        time.sleep(2)
                        st.rerun()
                    except Exception as e:
                        st.error(f"❌ Failed to create event: {str(e)}")

def validate_event_form(event_date: str, rsvp_by: str, event_title: str, 
                       event_host: str, event_location: str, pax: str) -> List[str]:
    """Validate event form data"""
    errors = []
    
    # Required field validation
    if not event_date.strip():
        errors.append("Event Date is required")
    elif not event_date.replace("/", "").isdigit() or len(event_date) != 8:
        errors.append("Event Date must be in MM/DD/YY format (e.g., 07/15/24)")
    
    if not rsvp_by.strip():
        errors.append("RSVP Deadline is required")
    elif not rsvp_by.replace("/", "").isdigit() or len(rsvp_by) != 8:
        errors.append("RSVP Deadline must be in MM/DD/YY format (e.g., 07/10/24)")
    
    if not event_title.strip():
        errors.append("Event Title is required")
    elif len(event_title.strip()) > 200:
        errors.append("Event Title must be 200 characters or less")
    
    if not event_host.strip():
        errors.append("Event Host is required")
    elif len(event_host.strip()) > 100:
        errors.append("Event Host must be 100 characters or less")
    
    if not event_location.strip():
        errors.append("Event Location is required")
    elif len(event_location.strip()) > 200:
        errors.append("Event Location must be 200 characters or less")
    
    if not pax.strip():
        errors.append("Number of Participants is required")
    elif not pax.isdigit() or int(pax) <= 0:
        errors.append("Number of Participants must be a positive integer")
    
    return errors
