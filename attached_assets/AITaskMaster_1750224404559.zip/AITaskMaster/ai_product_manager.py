import streamlit as st
from ai_service import AIService
import time
import pandas as pd

def render_ai_product_manager():
    """Render the AI Product Manager tab"""
    st.header("🤖 AI Product Manager - Week 4")
    
    # Initialize AI service
    ai_service = AIService()
    
    if not ai_service.client:
        st.error("⚠️ Azure OpenAI client not initialized. Please check your environment variables.")
        st.info("Required environment variables: AZURE_OPENAI_KEY, AZURE_OPENAI_ENDPOINT, AZURE_OPENAI_VERSION")
        return
    
    # Create tabs for different challenges
    tab1, tab2, tab3, tab4 = st.tabs([
        "🎯 Challenge 1: Product Ideation",
        "🔗 Challenge 2: Azure OpenAI Integration", 
        "🧠 Challenge 3: Prompt Engineering",
        "🔒 Challenge 4: RAG & Security"
    ])
    
    with tab1:
        render_product_ideation(ai_service)
    
    with tab2:
        render_azure_integration(ai_service)
    
    with tab3:
        render_prompt_engineering(ai_service)
    
    with tab4:
        render_rag_security(ai_service)

def render_product_ideation(ai_service: AIService):
    """Render Challenge 1: Product Ideation & Roadmap Development"""
    st.subheader("🎯 Challenge 1: Product Ideation & Roadmap Development")
    st.write("Simulate a Product Manager's workflow using AI for ideation, prioritization, and planning.")
    
    # Product Concept Generation
    st.markdown("### 1. Product Concept Generation")
    if st.button("🚀 Generate Product Idea", key="generate_product"):
        with st.spinner("Generating product concept..."):
            time.sleep(1)
            product_concept = ai_service.generate_product_idea()
            
            if product_concept:
                st.session_state.product_concept = product_concept
                st.markdown(product_concept)
            else:
                st.error("Failed to generate product concept")
    
    # Display stored product concept
    if 'product_concept' in st.session_state:
        with st.expander("📋 Current Product Concept", expanded=False):
            st.markdown(st.session_state.product_concept)
    
    # Feature Prioritization
    st.markdown("### 2. Feature Prioritization (MoSCoW Method)")
    if st.button("📊 Prioritize Features", key="prioritize_features"):
        if 'product_concept' not in st.session_state:
            st.warning("Please generate a product concept first!")
        else:
            with st.spinner("Brainstorming and prioritizing features..."):
                time.sleep(1.5)
                features = ai_service.prioritize_features(st.session_state.product_concept)
                
                if features:
                    st.session_state.prioritized_features = features
                    st.markdown(features)
                else:
                    st.error("Failed to prioritize features")
    
    # Display stored features
    if 'prioritized_features' in st.session_state:
        with st.expander("🎯 Prioritized Features", expanded=False):
            st.markdown(st.session_state.prioritized_features)
    
    # Roadmap Creation
    st.markdown("### 3. Roadmap Creation")
    if st.button("🗓️ Create 4-Quarter Roadmap", key="create_roadmap"):
        if 'product_concept' not in st.session_state or 'prioritized_features' not in st.session_state:
            st.warning("Please generate a product concept and prioritize features first!")
        else:
            with st.spinner("Creating development roadmap..."):
                time.sleep(1.5)
                roadmap = ai_service.create_roadmap(
                    st.session_state.product_concept,
                    st.session_state.prioritized_features
                )
                
                if roadmap:
                    st.session_state.roadmap = roadmap
                    st.markdown(roadmap)
                else:
                    st.error("Failed to create roadmap")
    
    # Display stored roadmap
    if 'roadmap' in st.session_state:
        with st.expander("🗓️ Development Roadmap", expanded=False):
            st.markdown(st.session_state.roadmap)
    
    # User Story Creation
    st.markdown("### 4. User Story Creation")
    feature_input = st.text_area(
        "Enter a feature description for user story creation:",
        placeholder="AI-powered fraud detection dashboard",
        key="feature_for_story"
    )
    
    if st.button("📝 Create User Story", key="create_user_story"):
        if not feature_input.strip():
            st.warning("Please enter a feature description!")
        else:
            with st.spinner("Creating user story..."):
                time.sleep(1)
                user_story = ai_service.create_user_story(feature_input)
                
                if user_story:
                    st.markdown(user_story)
                else:
                    st.error("Failed to create user story")
    
    # Export functionality
    st.markdown("### 📤 Export Results")
    if st.button("📄 Export All Results", key="export_ideation"):
        export_data = []
        
        if 'product_concept' in st.session_state:
            export_data.append(f"## Product Concept\n{st.session_state.product_concept}\n")
        
        if 'prioritized_features' in st.session_state:
            export_data.append(f"## Prioritized Features\n{st.session_state.prioritized_features}\n")
        
        if 'roadmap' in st.session_state:
            export_data.append(f"## Development Roadmap\n{st.session_state.roadmap}\n")
        
        if export_data:
            export_text = "\n".join(export_data)
            st.download_button(
                label="💾 Download as Markdown",
                data=export_text,
                file_name="product_ideation_results.md",
                mime="text/markdown"
            )
        else:
            st.warning("No results to export. Please generate content first!")

def render_azure_integration(ai_service: AIService):
    """Render Challenge 2: Azure OpenAI Integration"""
    st.subheader("🔗 Challenge 2: Azure OpenAI Integration")
    st.write("Programmatically interact with LLMs using Python and Azure OpenAI SDK.")
    
    # Environment Setup Display
    st.markdown("### 🔧 Environment Setup")
    with st.expander("Environment Variables Status", expanded=True):
        import os
        
        api_key = os.getenv('AZURE_OPENAI_KEY')
        endpoint = os.getenv('AZURE_OPENAI_ENDPOINT')
        version = os.getenv('AZURE_OPENAI_VERSION', '2024-02-15-preview')
        
        st.write("**Configuration Status:**")
        st.write(f"• API Key: {'✅ Set' if api_key else '❌ Not Set'}")
        st.write(f"• Endpoint: {'✅ Set' if endpoint else '❌ Not Set'}")
        st.write(f"• API Version: {version}")
        
        if not api_key or not endpoint:
            st.error("⚠️ Azure OpenAI credentials are missing!")
            st.code("""
# Required environment variables:
AZURE_OPENAI_KEY=your_key
AZURE_OPENAI_ENDPOINT=your_endpoint
AZURE_OPENAI_VERSION=2024-02-15-preview
            """)
    
    # Cybersecurity Analysis
    st.markdown("### 🔒 Cybersecurity Analysis")
    
    security_topics = [
        "DNS security and vulnerabilities",
        "Encryption algorithms and implementation",
        "Two-Factor Authentication (2FA) mechanisms",
        "SSL/TLS certificate validation",
        "API security best practices"
    ]
    
    selected_topic = st.selectbox(
        "Select a cybersecurity topic to analyze:",
        security_topics,
        key="security_topic"
    )
    
    custom_topic = st.text_input(
        "Or enter a custom topic:",
        placeholder="Blockchain security",
        key="custom_security_topic"
    )
    
    if st.button("🔍 Analyze Security Topic", key="analyze_security"):
        topic = custom_topic if custom_topic.strip() else selected_topic
        
        with st.spinner(f"Analyzing {topic}..."):
            time.sleep(1.5)
            analysis = ai_service.cybersecurity_analysis(topic)
            
            if analysis:
                st.markdown("#### 🛡️ Security Analysis Results")
                st.markdown(analysis)
                
                # Token count
                token_count = ai_service.count_tokens(analysis)
                st.info(f"📊 Response contains {token_count} tokens")
            else:
                st.error("Failed to generate security analysis")
    
    # Parameter Tuning Experiment
    st.markdown("### ⚙️ Parameter Tuning Experiment")
    
    test_query = st.text_area(
        "Enter a query for parameter comparison:",
        value="Explain the importance of network segmentation in cybersecurity",
        key="tuning_query"
    )
    
    col1, col2 = st.columns(2)
    
    with col1:
        st.markdown("**Short Response (200 tokens)**")
        if st.button("📝 Generate Short", key="short_tokens"):
            with st.spinner("Generating short response..."):
                time.sleep(1)
                response = ai_service.generate_response(
                    [{"role": "user", "content": test_query}],
                    temperature=0.7,
                    max_completion_tokens=200
                )
                
                if response:
                    st.session_state.short_response = response
                    st.markdown(response)
                    st.info(f"Tokens: {ai_service.count_tokens(response)}")
    
    with col2:
        st.markdown("**Long Response (500 tokens)**")
        if st.button("📄 Generate Long", key="long_tokens"):
            with st.spinner("Generating long response..."):
                time.sleep(1)
                response = ai_service.generate_response(
                    [{"role": "user", "content": test_query}],
                    temperature=0.7,
                    max_completion_tokens=500
                )
                
                if response:
                    st.session_state.long_response = response
                    st.markdown(response)
                    st.info(f"Tokens: {ai_service.count_tokens(response)}")
    
    # Comparison table
    if 'short_response' in st.session_state and 'long_response' in st.session_state:
        st.markdown("#### 📊 Parameter Comparison")
        
        comparison_data = {
            "Parameter": ["Max Completion Tokens", "Actual Response Length", "Detail Level", "Use Case"],
            "Short Response": [
                "200",
                f"{ai_service.count_tokens(st.session_state.short_response)} tokens",
                "Concise & Summary",
                "Quick answers, overviews"
            ],
            "Long Response": [
                "500", 
                f"{ai_service.count_tokens(st.session_state.long_response)} tokens",
                "Detailed & Comprehensive",
                "In-depth explanations, tutorials"
            ]
        }
        
        df = pd.DataFrame(comparison_data)
        st.table(df)

def render_prompt_engineering(ai_service: AIService):
    """Render Challenge 3: Advanced Prompt Engineering"""
    st.subheader("🧠 Challenge 3: Advanced Prompt Engineering")
    st.write("Master prompting techniques and token optimization.")
    
    # Zero-Shot vs Few-Shot
    st.markdown("### 🎯 Zero-Shot vs Few-Shot Comparison")
    
    comparison_query = st.text_input(
        "Enter a question for prompting comparison:",
        value="Explain quantum computing",
        key="comparison_query"
    )
    
    if st.button("🔬 Compare Prompting Techniques", key="compare_prompting"):
        if not comparison_query.strip():
            st.warning("Please enter a question!")
        else:
            with st.spinner("Comparing zero-shot vs few-shot responses..."):
                time.sleep(2)
                responses = ai_service.compare_prompting_techniques(comparison_query)
                
                col1, col2 = st.columns(2)
                
                with col1:
                    st.markdown("#### Zero-Shot Response")
                    if responses["zero_shot"] and responses["zero_shot"] != "Error generating response":
                        st.markdown(responses["zero_shot"])
                        st.info(f"Tokens: {ai_service.count_tokens(responses['zero_shot'])}")
                    else:
                        st.error("Failed to generate zero-shot response")
                
                with col2:
                    st.markdown("#### Few-Shot Response")
                    if responses["few_shot"] and responses["few_shot"] != "Error generating response":
                        st.markdown(responses["few_shot"])
                        st.info(f"Tokens: {ai_service.count_tokens(responses['few_shot'])}")
                    else:
                        st.error("Failed to generate few-shot response")
    
    # Chain-of-Thought Reasoning
    st.markdown("### 🔗 Chain-of-Thought (CoT) Reasoning")
    
    reasoning_problems = [
        "A store has 12 apples. They sold 5 and bought 8 more. How many apples do they have now?",
        "If a cybersecurity team detects 50 threats per day and blocks 90% of them, how many threats get through in a week?",
        "A company has 3 data centers. Each center processes 1000 requests per minute. If one center goes down, what's the new processing capacity?"
    ]
    
    selected_problem = st.selectbox(
        "Select a problem for CoT reasoning:",
        reasoning_problems,
        key="cot_problem"
    )
    
    custom_problem = st.text_area(
        "Or enter a custom problem:",
        placeholder="Your step-by-step problem here...",
        key="custom_cot_problem"
    )
    
    if st.button("🧮 Solve with Chain-of-Thought", key="solve_cot"):
        problem = custom_problem if custom_problem.strip() else selected_problem
        
        with st.spinner("Thinking step by step..."):
            time.sleep(1.5)
            solution = ai_service.chain_of_thought_reasoning(problem)
            
            if solution:
                st.markdown("#### 🎯 Step-by-Step Solution")
                st.markdown(solution)
                st.info(f"Response tokens: {ai_service.count_tokens(solution)}")
            else:
                st.error("Failed to generate solution")
    
    # Token Efficiency
    st.markdown("### ⚡ Token Efficiency Optimization")
    
    col1, col2 = st.columns(2)
    
    with col1:
        st.markdown("#### Original Prompt")
        original_prompt = st.text_area(
            "Enter a verbose prompt to optimize:",
            value="In light of recent developments in the field of artificial intelligence and machine learning, could you please elucidate the fundamental concepts and principles...",
            height=100,
            key="original_prompt"
        )
        
        if original_prompt:
            original_tokens = ai_service.count_tokens(original_prompt)
            st.info(f"Original tokens: {original_tokens}")
    
    with col2:
        st.markdown("#### Optimized Prompt")
        optimized_prompt = st.text_area(
            "Enter the optimized version:",
            value="Explain recent AI and ML concepts",
            height=100,
            key="optimized_prompt"
        )
        
        if optimized_prompt:
            optimized_tokens = ai_service.count_tokens(optimized_prompt)
            st.info(f"Optimized tokens: {optimized_tokens}")
            
            if original_prompt:
                original_token_count = ai_service.count_tokens(original_prompt)
                savings = original_token_count - optimized_tokens
                percentage = (savings / original_token_count) * 100 if original_token_count > 0 else 0
                st.success(f"Token savings: {savings} ({percentage:.1f}%)")
    
    # Token Analysis
    if st.button("📊 Analyze Token Efficiency", key="analyze_tokens"):
        if not original_prompt.strip() or not optimized_prompt.strip():
            st.warning("Please enter both original and optimized prompts!")
        else:
            original_token_count = ai_service.count_tokens(original_prompt)
            optimized_token_count = ai_service.count_tokens(optimized_prompt)
            
            analysis_data = {
                "Metric": ["Token Count", "Character Count", "Word Count", "Efficiency Gain"],
                "Original": [
                    original_token_count,
                    len(original_prompt),
                    len(original_prompt.split()),
                    "Baseline"
                ],
                "Optimized": [
                    optimized_token_count,
                    len(optimized_prompt),
                    len(optimized_prompt.split()),
                    f"{((original_token_count - optimized_token_count) / original_token_count * 100):.1f}% reduction" if original_token_count > 0 else "0% reduction"
                ]
            }
            
            df = pd.DataFrame(analysis_data)
            st.table(df)

def render_rag_security(ai_service: AIService):
    """Render Challenge 4: RAG & Security Implementation"""
    st.subheader("🔒 Challenge 4: RAG & Security Implementation")
    st.write("Build a secure RAG pipeline with Azure Blob Storage considerations.")
    
    # Local RAG Setup Simulation
    st.markdown("### 📁 Local RAG Setup")
    
    st.info("""
    **Simulated Document Storage Structure:**
    ```
    documents/
    ├── cybersecurity_fundamentals.txt
    ├── ai_security_best_practices.txt
    └── threat_detection_methods.txt
    ```
    """)
    
    # Document upload simulation
    st.markdown("#### 📄 Document Management")
    
    uploaded_files = st.file_uploader(
        "Upload documents for RAG processing:",
        type=['txt', 'md', 'pdf'],
        accept_multiple_files=True,
        key="rag_documents"
    )
    
    if uploaded_files:
        st.success(f"✅ {len(uploaded_files)} document(s) uploaded for processing")
        
        # Display document information
        for file in uploaded_files:
            with st.expander(f"📄 {file.name}"):
                if file.type == "text/plain":
                    content = str(file.read(), "utf-8")
                    st.text_area(f"Content preview ({file.name}):", content[:500] + "..." if len(content) > 500 else content, height=150)
                    st.info(f"File size: {len(content)} characters, Estimated tokens: {ai_service.count_tokens(content)}")
                else:
                    st.info(f"File type: {file.type}, Size: {file.size} bytes")
    
    # RAG Query Interface
    st.markdown("### 🔍 RAG Query Interface")
    
    sample_queries = [
        "What are the best practices for securing AI models?",
        "How can we detect adversarial attacks on machine learning systems?",
        "What security measures should be implemented for API endpoints?",
        "Explain the OWASP Top 10 for machine learning security"
    ]
    
    selected_query = st.selectbox(
        "Select a sample query:",
        sample_queries,
        key="rag_query_select"
    )
    
    custom_query = st.text_input(
        "Or enter a custom security query:",
        placeholder="How to implement secure RAG pipelines?",
        key="rag_custom_query"
    )
    
    if st.button("🔍 Process RAG Query", key="process_rag"):
        query = custom_query if custom_query.strip() else selected_query
        
        with st.spinner("Processing RAG query..."):
            time.sleep(1.5)
            
            # Simulate RAG processing
            st.markdown("#### 🎯 RAG Response")
            
            rag_context = """
            **Retrieved Context:** Based on cybersecurity documentation and AI security best practices...
            """
            
            # Generate response with context
            enhanced_query = f"Based on cybersecurity and AI security documentation, {query}"
            response = ai_service.generate_response(
                [{"role": "system", "content": "You are a cybersecurity expert with access to security documentation."},
                 {"role": "user", "content": enhanced_query}],
                temperature=0.3,
                max_completion_tokens=400
            )
            
            if response:
                st.markdown(rag_context)
                st.markdown(response)
                st.info(f"Response tokens: {ai_service.count_tokens(response)}")
            else:
                st.error("Failed to process RAG query")
    
    # Azure Integration Recommendations
    st.markdown("### ☁️ Azure Services Integration")
    
    azure_services = {
        "Azure AI Search": {
            "Purpose": "Vector search and document indexing",
            "Use Case": "Efficient similarity search across document embeddings",
            "Security Features": "Encryption at rest, network isolation, RBAC"
        },
        "Azure Cognitive Services": {
            "Purpose": "Entity recognition and text analytics", 
            "Use Case": "Extract and classify sensitive information from documents",
            "Security Features": "Data residency controls, audit logging, private endpoints"
        },
        "Azure Blob Storage": {
            "Purpose": "Secure document storage",
            "Use Case": "Store and version control RAG documents",
            "Security Features": "Immutable storage, lifecycle policies, encryption"
        },
        "Azure Key Vault": {
            "Purpose": "Secrets and key management",
            "Use Case": "Store API keys and encryption keys securely", 
            "Security Features": "Hardware security modules, access policies, audit logs"
        }
    }
    
    for service, details in azure_services.items():
        with st.expander(f"🔧 {service}"):
            st.write(f"**Purpose:** {details['Purpose']}")
            st.write(f"**Use Case:** {details['Use Case']}")
            st.write(f"**Security Features:** {details['Security Features']}")
    
    # Security Vulnerability Mitigation
    st.markdown("### 🛡️ Security Vulnerability Mitigation")
    
    vulnerabilities = {
        "Training Data Poisoning": {
            "Risk": "Malicious data injection during model training",
            "Mitigation": "Data validation pipelines, source verification, anomaly detection",
            "Implementation": "Implement checksum validation, data lineage tracking, and automated quality checks"
        },
        "Model Extraction": {
            "Risk": "Unauthorized access to model parameters and architecture",
            "Mitigation": "API rate limiting, query obfuscation, differential privacy",
            "Implementation": "Implement request throttling, add noise to outputs, monitor query patterns"
        },
        "Data Leakage": {
            "Risk": "Sensitive information exposure through model outputs",
            "Mitigation": "Output filtering, PII detection, response sanitization",
            "Implementation": "Use regex patterns, NER models, and content filtering rules"
        },
        "Supply Chain Attacks": {
            "Risk": "Compromised dependencies and model artifacts",
            "Mitigation": "Signed model artifacts, dependency scanning, secure CI/CD",
            "Implementation": "Implement artifact signing, vulnerability scanning, and secure build environments"
        }
    }
    
    selected_vuln = st.selectbox(
        "Select a vulnerability to explore:",
        list(vulnerabilities.keys()),
        key="vuln_select"
    )
    
    vuln_details = vulnerabilities[selected_vuln]
    
    col1, col2 = st.columns(2)
    
    with col1:
        st.markdown(f"#### 🚨 {selected_vuln}")
        st.write(f"**Risk:** {vuln_details['Risk']}")
        st.write(f"**Mitigation Strategy:** {vuln_details['Mitigation']}")
    
    with col2:
        st.markdown("#### 🔧 Implementation Details")
        st.write(vuln_details['Implementation'])
    
    # Generate custom mitigation strategy
    if st.button("🧠 Generate Custom Mitigation Strategy", key="generate_mitigation"):
        with st.spinner("Generating security recommendations..."):
            time.sleep(1.5)
            
            mitigation_query = f"Provide detailed mitigation strategies for {selected_vuln} in AI/ML systems, including specific implementation steps and monitoring approaches."
            
            strategy = ai_service.generate_response(
                [{"role": "system", "content": "You are a cybersecurity expert specializing in AI/ML security."},
                 {"role": "user", "content": mitigation_query}],
                temperature=0.2,
                max_completion_tokens=500
            )
            
            if strategy:
                st.markdown("#### 🎯 Custom Mitigation Strategy")
                st.markdown(strategy)
            else:
                st.error("Failed to generate mitigation strategy")
    
    # Security Assessment Table
    st.markdown("### 📊 Security Assessment Summary")
    
    if st.button("📋 Generate Security Assessment", key="security_assessment"):
        assessment_data = []
        
        for vuln, details in vulnerabilities.items():
            assessment_data.append({
                "Vulnerability": vuln,
                "Risk Level": "🔴 High" if vuln in ["Training Data Poisoning", "Data Leakage"] else "🟡 Medium",
                "Mitigation Status": "✅ Implemented" if vuln in ["Model Extraction"] else "🔄 In Progress",
                "Priority": "P1" if vuln in ["Data Leakage"] else "P2"
            })
        
        df = pd.DataFrame(assessment_data)
        st.table(df)
        
        # Export assessment
        st.download_button(
            label="📄 Export Security Assessment",
            data=df.to_csv(index=False),
            file_name="security_assessment.csv",
            mime="text/csv"
        )
