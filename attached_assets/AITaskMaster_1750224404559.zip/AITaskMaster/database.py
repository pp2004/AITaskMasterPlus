import sqlite3
import os
from typing import List, Optional
from models import Event, Host
import json

class DatabaseManager:
    def __init__(self, db_path: str = "events.db"):
        self.db_path = db_path
        self.init_database()
    
    def init_database(self):
        """Initialize the database with required tables"""
        with sqlite3.connect(self.db_path) as conn:
            cursor = conn.cursor()
            
            # Create events table
            cursor.execute('''
                CREATE TABLE IF NOT EXISTS events (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    eventDate TEXT NOT NULL,
                    status INTEGER NOT NULL DEFAULT 0,
                    rsvpBy TEXT NOT NULL,
                    eventTitle TEXT NOT NULL,
                    eventHost TEXT NOT NULL,
                    eventLocation TEXT NOT NULL,
                    pax TEXT NOT NULL,
                    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
                )
            ''')
            
            # Create hosts table
            cursor.execute('''
                CREATE TABLE IF NOT EXISTS hosts (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    gpn TEXT UNIQUE NOT NULL,
                    name TEXT NOT NULL
                )
            ''')
            
            # Insert sample hosts if table is empty
            cursor.execute('SELECT COUNT(*) FROM hosts')
            if cursor.fetchone()[0] == 0:
                sample_hosts = [
                    ("43746091", "MUHAMMAD AZLAN BIN HASSAN"),
                    ("43746115", "CHEW SHI DA, ERIC")
                ]
                cursor.executemany('INSERT INTO hosts (gpn, name) VALUES (?, ?)', sample_hosts)
            
            conn.commit()
    
    def create_event(self, event_data: dict) -> int:
        """Create a new event and return its ID"""
        with sqlite3.connect(self.db_path) as conn:
            cursor = conn.cursor()
            cursor.execute('''
                INSERT INTO events (eventDate, status, rsvpBy, eventTitle, eventHost, eventLocation, pax)
                VALUES (?, ?, ?, ?, ?, ?, ?)
            ''', (
                event_data['eventDate'],
                event_data['status'],
                event_data['rsvpBy'],
                event_data['eventTitle'],
                event_data['eventHost'],
                event_data['eventLocation'],
                event_data['pax']
            ))
            return cursor.lastrowid
    
    def get_all_events(self) -> List[Event]:
        """Get all events from the database"""
        with sqlite3.connect(self.db_path) as conn:
            cursor = conn.cursor()
            cursor.execute('SELECT * FROM events ORDER BY eventDate DESC')
            rows = cursor.fetchall()
            
            events = []
            for row in rows:
                event = Event(
                    id=row[0],
                    eventDate=row[1],
                    status=row[2],
                    rsvpBy=row[3],
                    eventTitle=row[4],
                    eventHost=row[5],
                    eventLocation=row[6],
                    pax=row[7]
                )
                events.append(event)
            
            return events
    
    def get_event_by_id(self, event_id: int) -> Optional[Event]:
        """Get a specific event by ID"""
        with sqlite3.connect(self.db_path) as conn:
            cursor = conn.cursor()
            cursor.execute('SELECT * FROM events WHERE id = ?', (event_id,))
            row = cursor.fetchone()
            
            if row:
                return Event(
                    id=row[0],
                    eventDate=row[1],
                    status=row[2],
                    rsvpBy=row[3],
                    eventTitle=row[4],
                    eventHost=row[5],
                    eventLocation=row[6],
                    pax=row[7]
                )
            return None
    
    def update_event(self, event_id: int, event_data: dict) -> bool:
        """Update an existing event"""
        with sqlite3.connect(self.db_path) as conn:
            cursor = conn.cursor()
            cursor.execute('''
                UPDATE events 
                SET eventDate=?, status=?, rsvpBy=?, eventTitle=?, eventHost=?, eventLocation=?, pax=?
                WHERE id=?
            ''', (
                event_data['eventDate'],
                event_data['status'],
                event_data['rsvpBy'],
                event_data['eventTitle'],
                event_data['eventHost'],
                event_data['eventLocation'],
                event_data['pax'],
                event_id
            ))
            return cursor.rowcount > 0
    
    def delete_event(self, event_id: int) -> bool:
        """Delete an event by ID"""
        with sqlite3.connect(self.db_path) as conn:
            cursor = conn.cursor()
            cursor.execute('DELETE FROM events WHERE id = ?', (event_id,))
            return cursor.rowcount > 0
    
    def get_all_hosts(self) -> List[Host]:
        """Get all hosts from the database"""
        with sqlite3.connect(self.db_path) as conn:
            cursor = conn.cursor()
            cursor.execute('SELECT gpn, name FROM hosts ORDER BY name')
            rows = cursor.fetchall()
            
            return [Host(gpn=row[0], name=row[1]) for row in rows]
