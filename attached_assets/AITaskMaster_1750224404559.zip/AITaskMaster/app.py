import streamlit as st
import os
from dotenv import load_dotenv
from event_planner import render_event_planner
from ai_product_manager import render_ai_product_manager

# Load environment variables
load_dotenv()

def main():
    st.set_page_config(
        page_title="AI-Powered Event & Product Management",
        page_icon="🚀",
        layout="wide",
        initial_sidebar_state="expanded"
    )
    
    # Dark mode toggle
    with st.sidebar:
        st.header("Settings")
        dark_mode = st.toggle("Dark Mode", value=False, key="dark_mode_toggle")
        
        # Apply dark mode styling
        if dark_mode:
            st.markdown("""
            <style>
            .main .block-container {
                background-color: #0e1117;
                color: #fafafa;
            }
            .stApp {
                background-color: #0e1117;
                color: #fafafa;
            }
            .stSelectbox > div > div {
                background-color: #262730;
                color: #fafafa;
            }
            .stTextInput > div > div > input {
                background-color: #262730;
                color: #fafafa;
                border: 1px solid #4a4a4a;
            }
            .stTextArea > div > div > textarea {
                background-color: #262730;
                color: #fafafa;
                border: 1px solid #4a4a4a;
            }
            .stDateInput > div > div > input {
                background-color: #262730;
                color: #fafafa;
                border: 1px solid #4a4a4a;
            }
            .stNumberInput > div > div > input {
                background-color: #262730;
                color: #fafafa;
                border: 1px solid #4a4a4a;
            }
            .stButton > button {
                background-color: #262730;
                color: #fafafa;
                border: 1px solid #4a4a4a;
            }
            .stButton > button:hover {
                background-color: #3a3a3a;
                border: 1px solid #6a6a6a;
            }
            .stDataFrame {
                background-color: #262730;
                color: #fafafa;
            }
            .stExpander {
                background-color: #262730;
                border: 1px solid #4a4a4a;
            }
            .stTabs {
                background-color: #262730;
            }
            .stMarkdown {
                color: #fafafa;
            }
            .stAlert > div {
                background-color: #262730;
                color: #fafafa;
                border: 1px solid #4a4a4a;
            }
            .stSpinner > div {
                border-color: #fafafa;
            }
            h1, h2, h3, h4, h5, h6 {
                color: #fafafa !important;
            }
            p, div, span, label {
                color: #fafafa !important;
            }
            .stSelectbox label {
                color: #fafafa !important;
            }
            .stTextInput label {
                color: #fafafa !important;
            }
            .stTextArea label {
                color: #fafafa !important;
            }
            .stDateInput label {
                color: #fafafa !important;
            }
            .stNumberInput label {
                color: #fafafa !important;
            }
            .stRadio label {
                color: #fafafa !important;
            }
            .stRadio > div {
                color: #fafafa !important;
            }
            .stCheckbox label {
                color: #fafafa !important;
            }
            .stFormSubmitButton > button {
                background-color: #ff4b4b;
                color: white;
            }
            .stFormSubmitButton > button:hover {
                background-color: #ff6b6b;
            }
            .css-1d391kg {
                background-color: #262730 !important;
            }
            .css-1lcbmhc {
                background-color: #262730 !important;
            }
            .css-17lntkn {
                background-color: #262730 !important;
            }
            .stSidebar {
                background-color: #262730 !important;
            }
            .stSidebar .stSelectbox > div > div {
                background-color: #262730 !important;
                color: #fafafa !important;
            }
            .stSidebar .stRadio > div {
                background-color: #262730 !important;
                color: #fafafa !important;
            }
            .stSidebar label {
                color: #fafafa !important;
            }
            .stSidebar h1, .stSidebar h2, .stSidebar h3 {
                color: #fafafa !important;
            }
            .css-1v3fvcr {
                background-color: #262730 !important;
            }
            .css-1y4p8pa {
                background-color: #0e1117 !important;
            }
            .css-12oz5g7 {
                background-color: #262730 !important;
            }
            </style>
            """, unsafe_allow_html=True)
        else:
            st.markdown("""
            <style>
            .main .block-container {
                background-color: #ffffff;
                color: #000000;
            }
            .stApp {
                background-color: #ffffff;
                color: #000000;
            }
            </style>
            """, unsafe_allow_html=True)
    
    st.title("🚀 AI-Powered Event & Product Management Platform")
    
    # Sidebar navigation
    with st.sidebar:
        st.header("Navigation")
        tab_choice = st.radio(
            "Select a tab:",
            ["📅 Week 2/3 - Event Planner", "🤖 Week 4 - AI Product Manager"],
            index=0
        )
        

    
    # Main content area
    if tab_choice == "📅 Week 2/3 - Event Planner":
        render_event_planner()
    elif tab_choice == "🤖 Week 4 - AI Product Manager":
        render_ai_product_manager()

if __name__ == "__main__":
    main()
