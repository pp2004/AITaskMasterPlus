from pydantic import BaseModel, Field, validator
from typing import Optional
from datetime import datetime
import re

class Event(BaseModel):
    id: Optional[int] = None
    eventDate: str = Field(..., description="Event date in MM/DD/YY format")
    status: int = Field(..., ge=0, le=2, description="0=open, 1=fully booked, 2=completed")
    rsvpBy: str = Field(..., description="RSVP deadline in MM/DD/YY format")
    eventTitle: str = Field(..., min_length=1, max_length=200)
    eventHost: str = Field(..., min_length=1, max_length=100)
    eventLocation: str = Field(..., min_length=1, max_length=200)
    pax: str = Field(..., description="Number of participants")
    
    @validator('eventDate', 'rsvpBy')
    def validate_date_format(cls, v):
        if not re.match(r'^\d{2}/\d{2}/\d{2}$', v):
            raise ValueError('Date must be in MM/DD/YY format')
        return v
    
    @validator('pax')
    def validate_pax(cls, v):
        if not v.isdigit() or int(v) <= 0:
            raise ValueError('Pax must be a positive integer')
        return v

class CreateEventRequest(BaseModel):
    eventDate: str
    status: int = Field(default=0, ge=0, le=2)
    rsvpBy: str
    eventTitle: str
    eventHost: str
    eventLocation: str
    pax: str

class Host(BaseModel):
    gpn: str
    name: str
